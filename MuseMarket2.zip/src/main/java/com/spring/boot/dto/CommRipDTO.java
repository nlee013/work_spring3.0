package com.spring.boot.dto;

public class CommRipDTO {

	private int commuRipNo;
	private int userNo;
	private int commuNo;
	private String commuRipContent;
	private String commuRipCreated;
	
	private String userId;
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public int getCommuRipNo() {
		return commuRipNo;
	}
	public void setCommuRipNo(int commuRipNo) {
		this.commuRipNo = commuRipNo;
	}
	public int getUserNo() {
		return userNo;
	}
	public void setUserNo(int userNo) {
		this.userNo = userNo;
	}
	public int getCommuNo() {
		return commuNo;
	}
	public void setCommuNo(int commuNo) {
		this.commuNo = commuNo;
	}
	public String getCommuRipContent() {
		return commuRipContent;
	}
	public void setCommuRipContent(String commuRipContent) {
		this.commuRipContent = commuRipContent;
	}
	public String getCommuRipCreated() {
		return commuRipCreated;
	}
	public void setCommuRipCreated(String commuRipCreated) {
		this.commuRipCreated = commuRipCreated;
	}
	
	
	
	
}
