package com.exe.springdi1;

public class MessageCall {

	public static void main(String[] args) {
	
		Message ob = new Message();
		
		ob.sayHello("�����");
	}

}
