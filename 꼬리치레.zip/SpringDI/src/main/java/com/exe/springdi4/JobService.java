package com.exe.springdi4;

public interface JobService {

	public void getJob();
}
