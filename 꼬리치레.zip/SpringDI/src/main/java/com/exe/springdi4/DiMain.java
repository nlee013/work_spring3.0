package com.exe.springdi4;

import org.springframework.context.support.GenericXmlApplicationContext;

public class DiMain {

	public static void main(String[] args) {

		//��ü ���� �� method ȣ���ϸ� ��
		/*
		 ServiceConsumer sc = new ServiceConsumer();
		 sc.consumerService();
	    */
		 GenericXmlApplicationContext context =
				 new GenericXmlApplicationContext("app-context.xml");
		 
		 ServiceConsumer sc = (ServiceConsumer) context.getBean("serviceConsumer");
		 sc.consumerService();
	}

}
