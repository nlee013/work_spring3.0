package com.exe.springdi4;

public interface TimeService {

	public String getTimeString();
}
