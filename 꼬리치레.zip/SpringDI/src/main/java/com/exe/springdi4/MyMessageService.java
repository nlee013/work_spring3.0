package com.exe.springdi4;

public class MyMessageService implements MessageService{

	public String getMessage() {
		
		return "�ȳ�, �ݰ���~~";
	}

}
