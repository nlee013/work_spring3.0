package com.exe.springdi3;

public class MessageMain {

	public static void main(String[] args) {//main��(console)�̴ϱ�

		MessageService ms = new MessageService();
		
		ms.messageService();//ȣ��
	}

}
