package com.exe.springdi3;

public interface Message {
	
	public void sayHello(String name);
	
}
